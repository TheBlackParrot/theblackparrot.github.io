pop_low.wav
> [mouthPop_02.wav](http://freesound.org/people/carlSablowEdwards/sounds/47498/) by [carlSablowEdwards](http://freesound.org/people/carlSablowEdwards/)

pop_high.wav
> [Cartoon Pop (Clean)](http://freesound.org/people/unfa/sounds/245645/) by [unfa](http://freesound.org/people/unfa/)

explosion_close.wav
> [blast.wav](http://freesound.org/people/Omar%20Alvarado/sounds/127951/) by [Omar Alvarado](http://freesound.org/people/Omar%20Alvarado/)

explosion_neither.wav
> [Explosion 3.aif](http://freesound.org/people/harpoyume/sounds/86026/) by [harpoyume](http://freesound.org/people/harpoyume/)

explosion_far.wav
> [Distant explosion.wav](http://freesound.org/people/juskiddink/sounds/108640/) by [juskiddink](http://freesound.org/people/juskiddink/)

level_up.wav
> [ping 2.wav](http://freesound.org/people/cameronmusic/sounds/138419/) by [cameronmusic](http://freesound.org/people/cameronmusic/)

place.wav
> [dup.mp3](http://freesound.org/people/zippi1/sounds/17945/) by [zippi1](http://freesound.org/people/zippi1/)

place_water.wav
> [Water bubble 7.wav](http://freesound.org/people/Quistard/sounds/166819/) by [Quistard](http://freesound.org/people/Quistard/)