registerOutputEvent(GameConnection, stopChallengeTimed, "int 0 999 0", 0);
registerOutputEvent(GameConnection, startChallengeTimed, "int 0 999 0", 0);

registerOutputEvent(GameConnection, unlockLevel, "int 0 999 0", 0);
registerOutputEvent(GameConnection, lockLevel, "int 0 999 0", 0);