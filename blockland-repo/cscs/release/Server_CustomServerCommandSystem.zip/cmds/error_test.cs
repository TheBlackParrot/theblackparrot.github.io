//AUTHOR	TheBlackParrot	18701
//INFO	Hopefully spits out a warning and skips it
//LIMIT	admin
//COMMAND	error test
//enabled

talk("This shouldn't execute...");