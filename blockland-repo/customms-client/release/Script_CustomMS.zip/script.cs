//original script by Trinick

$autoEnableCustomMS = true;

package enableCustomMS {
	function postServerTCPObj::connect(%this, %addr) {
		parent::connect(%this, "blmaster.theblackparrot.us:80");
		%this.cmd = strReplace(%this.cmd, "master2.blockland.us", "blmaster.theblackparrot.us");
	}

	function queryMasterTCPObj::connect(%this, %addr) {
		parent::connect(%this, "blmaster.theblackparrot.us:80");
		%this.cmd = strReplace(%this.cmd, "master2.blockland.us", "blmaster.theblackparrot.us");
	}
};

function toggleCustomMS() {
	$customMSActive = !$customMSActive;
	if($customMSActive)
		activatePackage(enableCustomMS);
	else
		deactivatePackage(enableCustomMS);
}

if($autoEnableCustomMS) {
	activatePackage(enableCustomMS);
	$customMSActive = true;
}