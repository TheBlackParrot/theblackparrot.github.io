exec("./script.cs");

%toggle = new GuiSwatchCtrl() {
	profile = "GuiDefaultProfile";
	horizSizing = "left";
	vertSizing = "bottom";
	position = "294 3";
	extent = "155 19";
	minExtent = "8 2";
	enabled = "1";
	visible = "1";
	clipToParent = "1";
	color = "255 255 255 128";

	new GuiCheckBoxCtrl() {
		profile = "GuiCheckBoxProfile";
		horizSizing = "right";
		vertSizing = "bottom";
		position = "5 -5";
		extent = "140 30";
		minExtent = "8 2";
		enabled = "1";
		visible = "1";
		clipToParent = "1";
		text = "Alternate Master Server";
		groupNum = "-1";
		buttonType = "ToggleButton";
		command = "toggleCustomMS();";
	};
};
JS_window.add(%toggle);
%toggle.getObject(0).setValue(1);